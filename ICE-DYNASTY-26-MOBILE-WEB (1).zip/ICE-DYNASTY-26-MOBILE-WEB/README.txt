ICE DYNASTY 26 — MOBILE WEB BUILD

Upload the CONTENTS of this folder to any static website host.
The public URL to index.html (or the folder root) is the game link.

Files:
- index.html — full mobile game
- manifest.webmanifest — install/app metadata
- sw.js — offline shell cache
- icon-192.png / icon-512.png — home-screen icons

Notes:
- Spotify/Apple Music embeds and NHL player images still need internet access.
- Save data stays in that browser/device unless exported/imported with the in-game Save Manager.
